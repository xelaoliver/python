
import datetime
import time
clear=lambda:print("\033c",end="",flush=True)
while True:
  clear()
  print("GMT BINARY TIME:")
  rtime=datetime.datetime.now()
  if rtime.hour+1>=13:
    print(bin((rtime.hour+1)-12)[2:],bin(rtime.minute)[2:],bin(rtime.second)[2:])
  else:
    print(bin(rtime.hour+1)[2:],bin(rtime.minute)[2:],bin(rtime.second)[2:])
  time.sleep(1)
