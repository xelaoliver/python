import random

clear=lambda:print("\033c",end="",flush=True)
cells=['-']*100
for i in range(20):
  cell=random.randint(0,99)
  if cells[cell]=="-":
    cells[cell]='M'

def check(item):
  global around
  around=0
  if item-10>=0 and cells[item-10]=="M":
    around+=1
  if item+10<=99 and cells[item+10]=="M":
    around+=1
  if item%10!=0 and cells[item-1]=="M":
    around+=1
  if item%9!=0 and cells[item+1]=="M":
    around+=1
  if item-11>=0 and item%10!=0 and cells[item-11]=="M":
    around+=1
  if item-9>=0 and item%10!=0 and cells[item-9]=="M":
    around+=1
  if item+11<=99 and item%10!=0 and cells[item+11]=="M":
    around+=1
  if item+9<=99 and item%10!=0 and cells[item+9]=="M":
    around+=1


while True:
  clear()
  i=0
  print("   0 1 2 3 4 5 6 7 8 9")
  while i<100:
    row=cells[i:i+10]
    
    for t in range(len(row)): # hides the mines
      if row[t]=='M':
        row[t]='-'
    
    if i==0:
      print(str("00"),*row)
    else:
      print(str(int(i/10)*10),*row)
    i+=10
  key=input()
  if key.isdigit() and int(key)<=100 and int(key)>=0:
    if cells[int(key)]=="M":
      print("You loose")
      break
    else:
      check(int(key))
      cells[int(key)]=around
    if "-" in cells:
      print("You win")
      break
