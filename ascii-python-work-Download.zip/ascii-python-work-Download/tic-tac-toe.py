from getkey import getkey,keys
clear=lambda:print("\033c",end="",flush=True)

def integer(store):
  try:
    int(store)
    return True
  except ValueError:
    return False

gamestate=True
state="Null"
def checkwin(team):
  global state
  global gamestate
  if data[0]==team and data[1]==team and data[2]==team:
    state=team
    gamestate=False
  if data[3]==team and data[4]==team and data[5]==team:
    state=team
    gamestate=False
  if data[6]==team and data[7]==team and data[8]==team:
    state=team
    gamestate=False
  if data[0]==team and data[3]==team and data[6]==team:
    state=team
    gamestate=False
  if data[1]==team and data[4]==team and data[7]==team:
    state=team
    gamestate=False
  if data[2]==team and data[5]==team and data[8]==team:
    state=team
    gamestate=False
  if data[0]==team and data[4]==team and data[8]==team:
    state=team
    gamestate=False
  if data[2]==team and data[4]==team and data[6]==team:
    state=False

key=0
data=["-","-","-","-","-","-","-","-","-",]
print(data[0],data[1],data[2],)
print(data[3],data[4],data[5],)
print(data[6],data[7],data[8],)
i=0
team=""

while gamestate:
  i+=1
  if i%2==0:
    team="O"
  else:
    team="X"

  while True:
    key=getkey()
    if integer(key) and int(key)<=9 and int(key)>=1 and data[int(key)-1]=="-":
      break
  print(key)
  data[int(key)-1]=team
  
  checkwin(team)
  
  clear()
  print(data[0],data[1],data[2],)
  print(data[3],data[4],data[5],)
  print(data[6],data[7],data[8],)

  if state=="X":
    print("X Wins!")
  if state=="O":
    print("O Wins!")
  if not("-" in data):
    print("Tie!")
    gamestate=False
