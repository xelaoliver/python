f=open("code.txt","r")
code=(f.read())
cells=[0]*30000
i=pointer=0
output=""
while i<len(code):
  function=code[i]
  if function=="+":
    cells[pointer]+=1%256
  if function=="-":
    cells[pointer]-=1%256
  if function==">":
    pointer+=1
  if function=="<":
    pointer-=1
  if function==".":
    output+=chr(cells[pointer])
  if function==",":
    cells[pointer]=ord(input()[0])
  if function=="[" and cells[pointer]==0:
    while code[i]!="]":
      i+=1
  if function=="]" and cells[pointer]!=0:
    while code[i]!="[":
      i-=1
  i+=1
print(output)
