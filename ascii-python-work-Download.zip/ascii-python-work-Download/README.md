# ascii-python-work
Here, the documented work, python files and extra ideas will be addressed. A̶l̶l Some of the code is written by myself.

*Including:*

- Hangman demake, including ASCII art graphics and random word generator!
- The 01000010 01001001 01001110 01000001 01010010 01011001 00100000 01000011 01001100 01001111 01000011 01001011 (BINARY CLOCK), a simple 12 line program that converts GMT to binary.
- Another demake of a popular game of the 1990s. MINESWEEPER. Again, this outputs in the console/terminal as ASCII but works just like a normal Minesweeper remake.
- Like Mineweeper, TIC-TAC-TOE is a commonly played game (both on computer and in... the real world).
- From TOM SCOTT's video from his series: THE BASICS. I created a python program that sorts through the many, many words in the english dictionary to find the longest and those who can be displayed on 7-segments.
- ASCII Loading bars and throbbers were put together very quickly. These are just for looks and do not represent the downloading, transferation or any means of data.
- BrainF*** Interpreter, is just an interpreter program in python!

*Extras and Simple Examples:*

- Estimate Pi. I'm sure it's an *okay* program.
- Unsort your sorted decimal data!
