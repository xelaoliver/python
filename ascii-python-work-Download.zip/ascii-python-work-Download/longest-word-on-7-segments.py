alpha=open("words_alpha.txt","r")
print(">>> Dictionary loaded")
line=alpha.readline()
nlargest=0
largest=""
print(">>> Delta loaded")
for item in alpha:
  if len(item)>=nlargest:
    nlargest=len(item)
    largest=item
    string=item
    boolean=string.__contains__('g' or 'k' or 'm' or 'q' or 'v' or 'w' or 'x' or 'v')
print(">>> Longest word displayable on 7 segments: ", largest, "with", nlargest, "characters.")
