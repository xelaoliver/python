denominator=1
equate=0
for counter in range(1000000):
  if counter%2==0:
    numerator=1
  else:
    numerator=-1
  equate+=numerator/denominator
  denominator+=2
print("Pi estimated:",equate*4)
