import random
data=[0,1,2,3,4,5,6,7,8,9]
print("Sorted data:", *data)
for i in range(len(data)):
  index1=random.randint(0,len(data)-1)
  index2=random.randint(0,len(data)-1)
  store=data[index1]
  data[index1]=data[index2]
  data[index2]=store
print("Unsorted data:", *data)
